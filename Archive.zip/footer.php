<?php
/**
 * The template for displaying the footer
 *
 */

?>
</div>

<footer class="site-footer">wp-simple</footer>

<?php wp_footer(); ?>

</body>
</html>